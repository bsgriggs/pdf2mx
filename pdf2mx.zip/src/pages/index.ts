// import { pages, IModel, texts } from "mendixmodelsdk";
// const DEFAULT_LANGUAGE = "en_us";
// export function createText(
//   model: IModel,
//   text: string,
//   languageCode?: string
// ): texts.Text {
//   const newTranslation = texts.Translation.create(model);
//   newTranslation.text = text;
//   newTranslation.languageCode = languageCode ? languageCode : DEFAULT_LANGUAGE;

//   const newText = texts.Text.create(model);
//   newText.translations.push(newTranslation);
//   console.debug("createText", text, newText);
//   return newText;
// }

// export function createClientTextTemplate(
//   model: IModel,
//   text: string,
//   languageCode?: string
// ): pages.ClientTemplate {
//   const newText = createText(model, text, languageCode);

//   const newClientTemplate = pages.ClientTemplate.create(model);
//   newClientTemplate.template = newText;
//   console.debug("createText", text, newClientTemplate);
//   return newClientTemplate;
// }
